<footer id="footer_area" class="footer_area_bg">
        <!-- start footer area -->

        <div class="container pt-50">
            <!-- start container -->
            <div class="row wow fadeInUp" data-wow-duration="1s" data-wow-delay=".7s">
                <!-- start row -->
                <div class="col-md-12 text-center  col-sm-12">
                    <!-- col-3 footer copyright -->
                    <div class="footer_copyright">
                        <p class="copyright_text text-center">Copyright © 2021. All rights reserved & designed by
                            <span><a href="#">Inksea team</a></span>.
                        </p>
                    </div>
                </div><!-- end col-3 footer copyright -->
            </div><!-- end row -->
        </div><!-- end container -->
    </footer><!-- end footer area -->
    <!-- Back to Top
	============================================= -->
    <a id="back-to-top" class="rounded-circle" data-toggle="tooltip" title="Back to Top" href="javascript:void(0)">
        <i class='bx bxs-chevron-up'></i>
    </a>

    <!-- CURSOR -->
    <div class="mouse-cursor cursor-outer"></div>
    <div class="mouse-cursor cursor-inner"></div>
    <!-- /CURSOR -->
    </div> <!-- Mouse Cursor Animation End -->

</body>