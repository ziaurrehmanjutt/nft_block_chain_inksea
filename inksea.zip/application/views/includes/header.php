<!doctype html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>INKSEA- Conect with tatoo Artists</title>
	<meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="artist" content="Inksea" />
	<!-- Favicon  -->
	<link rel="shortcut icon" href="<?=base_url('assets/')?>img/Inksea_171222021-04 (2).jpg">
	<!-- CSS File  -->
	<link rel="stylesheet" href="<?=base_url('assets/')?>css/bootstrap.min.css">
	<link rel="stylesheet" href="<?=base_url('assets/')?>css/owl.carousel.min.css">
	<link rel="stylesheet" href="<?=base_url('assets/')?>css/owl.theme.default.min.css">
	<link rel="stylesheet" href="<?=base_url('assets/')?>css/boxicons.min.css">
	<link rel="stylesheet" href="<?=base_url('assets/')?>css/magnific-popup.css">
	<link rel="stylesheet" href="<?=base_url('assets/')?>css/animate.css">
	<link rel="stylesheet" href="<?=base_url('assets/')?>css/macaw-elegant-tabs.css">
	<link rel="stylesheet" href="<?=base_url('assets/')?>css/nice-select.css">
	<link rel="stylesheet" href="<?=base_url('assets/')?>css/meanmenu.css">
	<link rel="stylesheet" href="<?=base_url('assets/')?>css/slick.css">
	<link rel="stylesheet" href="<?=base_url('assets/')?>css/style.css">
	<link rel="stylesheet" href="<?=base_url('assets/')?>css/responsive.css">
	<!-- End CSS File  -->
</head>