	<!-- Start JS File -->
	<script src="<?=base_url('assets/')?>js/modernizr-3.8.0.min.js"></script>
	<script src="<?=base_url('assets/')?>js/jquery-3.6.0.min.js"></script>
	<script src="<?=base_url('assets/')?>js/bootstrap.min.js"></script>
	<script src="<?=base_url('assets/')?>js/popper.min.js"></script>
	<script src="<?=base_url('assets/')?>js/jquery.appear.min.js"></script>
	<script src="<?=base_url('assets/')?>js/owl.carousel.min.js"></script>
	<script src="<?=base_url('assets/')?>js/jquery.magnific-popup.min.js"></script>
	<script src="<?=base_url('assets/')?>js/jquery.waypoints.min.js"></script>
	<script src="<?=base_url('assets/')?>js/wow.js"></script>
	<script src="<?=base_url('assets/')?>js/jquery.nice-select.min.js"></script>
	<script src="<?=base_url('assets/')?>js/count-to.js"></script>
	<script src="<?=base_url('assets/')?>js/macaw-tabs.js"></script>
	<script src="<?=base_url('assets/')?>js/multi-countdown.js"></script>
	<script src="<?=base_url('assets/')?>js/slick.min.js"></script>
	<script src="<?=base_url('assets/')?>js/jquery.meanmenu.min.js"></script>
	<script src="<?=base_url('assets/')?>js/main.js"></script>

	<script> 
		function copText(text){
			navigator.clipboard.writeText(text);
		}
	</script>
	<!-- End JS File -->
</html>