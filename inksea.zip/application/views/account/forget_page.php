
	<p>Welcome to InkSea Account Forget Password Email</p>	
	Clik 
	<a href="<?=$link?>">Here</a>  to Re-Genrate your Password
	<br>
	If link not clicked, Copy paste below url in browser bar 
<br>

<?=$link?>

	<h2>Thanks Using InkSea</h2>

