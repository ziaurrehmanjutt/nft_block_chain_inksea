<script>
   $(".search_input").change(function(){
       $('#search_form').submit();
    });
</script>