<?php
class Admin_Model extends CI_Model
{
    private $userID;
    public function __construct()
    {
        
    }
}